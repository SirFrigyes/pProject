package console;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class Console {

    private static void getRequestedNamesFromFile(String fileName, String namePar, String sortPar) {

        Map<String, Integer> names = new TreeMap<String, Integer>();

        try {

            File file = new File(fileName);
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(file);

            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr1 = xpath.compile("//datafield[@tag=\"100\"]");
            NodeList nl = (NodeList) expr1.evaluate(doc, XPathConstants.NODESET);

            for (int i = 0; i < nl.getLength(); i++) {

                Element e = (Element) nl.item(i);
                NodeList smallerNL = e.getElementsByTagName("subfield");

                for (int j = 0; j < smallerNL.getLength(); j++) {

                    if ("a".equals(smallerNL.item(j).getAttributes().getNamedItem("code").getNodeValue())) {
                        String name = smallerNL.item(j).getTextContent();

                        if (!"0".equals(namePar)) {
                           
                            if (name.substring(0, 1).equals(namePar.toUpperCase())) {
                                
                                if (names.isEmpty()) {
                                    names.put(name, 1);
                                } else {

                                    if (names.containsKey(name)) {
                                        names.put(name, names.getOrDefault(name, 0) + 1);
                                    } else {
                                        names.put(name, 1);
                                    }
                                }
                            }
                        } else {
                            if (names.isEmpty()) {
                                names.put(name, 1);
                            } else {

                                if (names.containsKey(name)) {
                                    names.put(name, names.getOrDefault(name, 0) + 1);
                                } else {
                                    names.put(name, 1);
                                }
                            }
                        }

                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        if ("1".equals(sortPar)) {
            names.entrySet()
                    .stream()
                    .sorted(Map.Entry.<String, Integer>comparingByKey())
                    .forEach(System.out::println);
        } else if ("0".equals(sortPar)) {
            names.entrySet()
                    .stream()
                    .sorted(Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder()))
                    .forEach(System.out::println);
        }

    }

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Add meg a file helyét:");
        String fileName = reader.readLine();

        System.out.println("Add meg a szűrni kívánt nevek kezdőbetűjét (Ha nem akarsz így szűkíteni, adj meg 0-át): ");
        String namePar = reader.readLine();

        System.out.println("Ha a nevek szerint szeretnél rendezni, írj 1-est, ha a megjelenés gyakorisága szerint, akkor 0-át: ");
        String sortPar = reader.readLine();

        getRequestedNamesFromFile(fileName, namePar, sortPar);
    }

}
