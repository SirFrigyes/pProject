
package Modell;

import java.io.File;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class xmlModell {
    
    public static Map<String, Integer> getRequestedNamesFromFile(String filePath, String namePar, String sortPar) {

        Map<String, Integer> names = new TreeMap<String, Integer>();

        try {

            File file = new File(filePath);
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(file);

            XPathFactory xPathfactory = XPathFactory.newInstance();
            XPath xpath = xPathfactory.newXPath();
            XPathExpression expr1 = xpath.compile("//datafield[@tag=\"100\"]");
            NodeList nl = (NodeList) expr1.evaluate(doc, XPathConstants.NODESET);
            System.out.println(nl.getLength());

            for (int i = 0; i < nl.getLength(); i++) {

                Element e = (Element) nl.item(i);
                NodeList smallerNL = e.getElementsByTagName("subfield");

                for (int j = 0; j < smallerNL.getLength(); j++) {

                    if ("a".equals(smallerNL.item(j).getAttributes().getNamedItem("code").getNodeValue())) {
                        String name = smallerNL.item(j).getTextContent();

                        if (!"0".equals(namePar)) {
                           
                            if (name.substring(0, 1).equals(namePar.toUpperCase())) {
                                
                                if (names.isEmpty()) {
                                    names.put(name, 1);
                                } else {

                                    if (names.containsKey(name)) {
                                        names.put(name, names.getOrDefault(name, 0) + 1);
                                    } else {
                                        names.put(name, 1);
                                    }
                                }
                            }
                        } else {
                            if (names.isEmpty()) {
                                names.put(name, 1);
                            } else {

                                if (names.containsKey(name)) {
                                    names.put(name, names.getOrDefault(name, 0) + 1);
                                } else {
                                    names.put(name, 1);
                                }
                            }
                        }

                    }
                }
            }
        } catch (Exception e) {
            names.clear();
            names.put("Hiba!", e.hashCode());
        }
        

        if ("1".equals(sortPar)) {
            return sortByKey(names);
        }
        else if ("0".equals(sortPar)) {
            /*names.entrySet()
            .stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder()));
            return names;*/
            
            return sortByValue(names);
        }
        return names;
    }
    
    private static Map<String, Integer> sortByKey(Map<String, Integer> m)
    {
        // Create a list from elements of HashMap
        List<Map.Entry<String, Integer> > list =
               new LinkedList<Map.Entry<String, Integer> >(m.entrySet());
 
        // Sort the list
        Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() {
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2)
            {
                return (o1.getKey()).compareTo(o2.getKey());
            }
        });
         
        // put data from sorted list to hashmap
        Map<String, Integer> temp = new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }
    
    private static Map<String, Integer> sortByValue(Map<String, Integer> m)
    {
        // Create a list from elements of HashMap
        List<Map.Entry<String, Integer> > list =
               new LinkedList<Map.Entry<String, Integer> >(m.entrySet());
 
        // Sort the list
        Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() {
            public int compare(Map.Entry<String, Integer> o1,
                               Map.Entry<String, Integer> o2)
            {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });
         
        // put data from sorted list to hashmap
        Map<String, Integer> temp = new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }
    
}
