A console alkalmazásról:

A beviteli értékeket nem ellenőrzöm, ha hibás adatokat adnánk meg a program szimplán crash-elne. Nem akartam vele sok időt húzni,
így is kicsit megcsúsztam.

A WebAlkalmazásról:

Mivel a program az előzőleg megírt consolos alkalmazást használja, ezért az ellenőrzés itt sem történik meg. Természetesen ezt most
megtehettem volna a servletben is, vagy akár létrehozhattam volna még egy Service classt, ami ezeket megoldja, egyszerűen nem akartam
vele időzni. Az adat kiíratása is viszonylag egyszerű, a servlet csak kiprinteli az adatokat, nem akartam erre sem időt pazarolni,
mert e-mailben azt az információt kaptam, hogy számít a beadási idő.

Mellékeltem kettő kiegészítő file-t is, mert ezeket alkalmaztam, a JSON végül is azt hiszem nem kellett, mert nem abban küldtem az adatokat, de nem néztem meg hogy ezt mindenhol átírtam-e